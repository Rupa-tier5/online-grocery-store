<!DOCTYPE html>
<html>
<head>
	<title>Add Item</title>
</head>
<body>
<form method="post">
	Quantity:<input type="number"name="quantity">
	<input type="submit"name="Add" Value="Add Item">
</form>
</body>
</html>
<?php
include "connection.php";
error_reporting(0);
$ids=$_GET['id'];
if(isset($_POST['Add']))
{
	$quantity=$_REQUEST['quantity'];
	$sql="update available_quantity set available_item=(available_item+'$quantity')where item_no=$ids";
	$res=mysqli_query($con,$sql);
	if($res){
		echo "<script>alert('item added sucessfully')</script>";
		echo "<script>window.location.href='/PHPPROJECT1/additem.php'</script>";
	}
	else
	{
		echo "<script>alert('Something went wrong')</script>";
		echo "<script>window.location.href='/PHPPROJECT1/additem.php'</script>";
	}
}
