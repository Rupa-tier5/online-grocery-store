<html>
<head>
	<title>LOG IN HERE</title>
  <style>
  body{
    margin: 0px;
    padding: 0px;
    background: url("image/store.jpg");
    background-size: cover;
    background-position: center;
    font-family: sans-serif;
    padding: 10px 30px;
  }
  .loginbox{
    width: 320px;
    height: 420px;
    background-color:rgb(0,0,0,0.7);
    color: #fff;
    top: 50%;
    left: 50%;
    position: absolute;
    transform: translate(-50%,-50%);
    box-sizing: border-box;
    padding: 70px 30px;
  }
  .avatar{
    width: 100px;
    height: 100px;
    border-radius: 50%;
    position: absolute;
    top: -50px;
    left: calc(50% - 50px);
  }
  h1
  {
    margin: 0;
    padding: 0 0 20px;
    text-align: center;
    font-size: 22px
  }
  .loginbox p{
    margin: 0;
    padding: 0;
    font-weight: bold;
  }
  .loginbox input{
    width: 100%;
    margin-bottom: :20px;
  }
  .loginbox input[type="text"],input[type="password"]
  {
    border:none;
    border-bottom: 1px solid #fff;
    background: transparent;
    outline: none;
    height: 40px;
    color: #fff;
    font-size: 16px;
  }
  .loginbox input[type="submit"]
  {
    border: none;
    outline: none;
    height: 40px;
    background: #fb2525;
    color: #fff;
    font-size: 18px;
    border-radius: 20px;
  }
  .loginbox input[type="submit"]:hover
  {
    cursor: pointer;
    background: #ffc107;
    color: #000;
  }
.loginbox a{
  text-decoration: none;
  font-size: 12px;
  line-height: 20px;
  color: darkgray;

}
.rem{
  transform: translate(0px, -19px);
}
</style>
<P><center><b><h1 style="color:#F7361C">ＧＲＯＣＥＲＹ ＣＡＲＴ</h1></b></center></p>
</head>
<body>
  <div class="loginbox">
    <image src="image/profile.png" class="avatar">
    <h1>LOG IN HERE</h1>
    <form action="/PHPPROJECT1/cart.php"  method="post">
    <p>Username</p>
     <input type="text" name="user" required>
     <p>Password</p>
    <input type="password"name="pass" required></br><br>
	<input type="submit" name="login" value="Login"><br></br>
	<a href="/PHPPROJECT1/registration.php">Register Here</a>
    
</form>
</div>
</body>
</html>