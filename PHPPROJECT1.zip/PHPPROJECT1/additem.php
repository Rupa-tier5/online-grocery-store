<!DOCTYPE html>
<html>
<head>
	<title>fetch data</title>
</head>
<body>
<form method="post">
	<center><input type="submit" name="submit" value="Available Item"></center>
</form>
</body>
</html>
<?php
  include "connection.php";
   if(isset($_POST['submit'])){
   	$sql="select item_no,item,available_item from available_quantity";
   	$res=mysqli_query($con,$sql);
   	if(mysqli_num_rows($res)>0){
   		echo"<center><table>";
   		echo"<tr>";
   		echo"<th>Item_No</th>";
   		echo"<th>Item</th>";
   		echo"<th>Available_Item</th>";
   		echo"</tr>";
   		while($row=mysqli_fetch_assoc($res))
   		{
   			echo"<tr>";
   			echo"<td>".$row['item_no']."</td>";
   			echo"<td>".$row['item']."</td>";
   			echo"<td>".$row['available_item']."</td>";
            echo"<td><button type='submit' name='btn'><a href='/PHPPROJECT1/update1.php/?id=$row[item_no] & nm=$row[item] & quantity=$row[available_item]'>ADD ITEM</a></button></td>";
            
   			echo"</tr>";
   		
   		}
   	}
   	echo"</table></center>";
   }

?>