<?php
include "connection.php";
error_reporting(0);
if(isset($_REQUEST['confirm']))
{
	$item=$_REQUEST['hidden_name'];
	$quantity=$_REQUEST['quantity'];
	$query="update available_quantity set order_quantity=0";
	$res=mysqli_query($con,$query);
	if($res){
		echo "<script>alert('Thank You for shopping with us')</script>";
		echo '<script>window.location="userlogin.php"</script>';
	}
	else
	{
		echo "<script>alert('Place Order')</script>";
		echo '<script>window.location="userlogin.php"</script>';
	}
	

}




		