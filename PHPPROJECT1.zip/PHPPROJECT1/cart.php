<?php
	error_reporting(0);
   session_start();
   include "connection.php";
	$ids=$_GET['id'];
    if(isset($_POST["add"])){
	$item=$_POST['hidden_name'];
	$quantity=$_POST['quantity'];
	$query="update available_quantity set available_item=(available_item-'$quantity'),order_quantity='$quantity' where item_no=$ids";
	$result=mysqli_query($con,$query);
	   if($result)
	   {
		   echo'<script>alert("Add to cart")</script>';
		   echo '<script>window.location="cart.php"</script>';
	   }
        if (isset($_SESSION["cart"])){
            $item_array_id = array_column($_SESSION["cart"],"product_id");
            if (!in_array($_GET["id"],$item_array_id)){
                $count = count($_SESSION["cart"]);
                $item_array = array(
                    'product_id' => $_GET["id"],
                    'item_name' => $_POST["hidden_name"],
                    'product_price' => $_POST["hidden_price"],
                    'item_quantity' => $_POST["quantity"],
                );
                $_SESSION["cart"][$count] = $item_array;
                echo '<script>window.location="cart.php"</script>';
            }else{
                echo '<script>alert("Product is already Added to Cart")</script>';
                echo '<script>window.location="cart.php"</script>';
            }
        }else{
            $item_array = array(
                'product_id' => $_GET["id"],
                'item_name' => $_POST["hidden_name"],
                'product_price' => $_POST["hidden_price"],
                'item_quantity' => $_POST["quantity"],
            );
            $_SESSION["cart"][0] = $item_array;
        }
    }

    if (isset($_GET["action"])){
        if ($_GET["action"] == "delete"){
            foreach ($_SESSION["cart"] as $keys => $value){
                if ($value["product_id"] == $_GET["id"]){
                    unset($_SESSION["cart"][$keys]);
                    echo '<script>alert("Product has been Removed...!")</script>';
                    echo '<script>window.location="cart.php"</script>';
                }
            }
        }
    }
?>

<!doctype html>
<html>
<head>

    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Shopping Cart</title>

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!--script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script-->
     <link rel="stylesheet" href="grocery.css"/>
	 <!--script>
	 function stickyMenu(){
		 var sticky=document.getElementById('sticky');
		 if(window.pageYOffset>220){
			 sticky.classList.add('sticky');
		 }
		 else{
			 sticky.classList.remove('sticky');
		 }
	 }
	 window.onscroll=function(){
		 stickyMenu();
	 }
	 </script-->
    <style>
        @import url('https://fonts.googleapis.com/css?family=Titillium+Web');


        *{
            font-family: 'Titillium Web', sans-serif;
        }
		.container{
			margin:50px 50px 50px 5%;
			width:90%;
			text-align:center;
			
		}
        .product{
			width:max-content;
			margin:25px;
			border:1px solid #184d47;
			border-radius:0 0 50px 50px;
			display:inline-block;
          
        }
        table, th, tr{
            text-align: center;
        }
        .title2{
            text-align: center;
            color: #66afe9;
            background-color: #efefef;
            padding: 2%;
        }
        h2{
					background-image:linear-gradient(to right,#40E0D0, #DFFF00);
					color:snow;
					font-family:fantasy;
					font-size:40px;
					padding:50px;
					font-variant:small-caps;
					
        }
        table th{
            background-color: #efefef;
        }
		.item-image{
			height:150px;
			width:150px;
			border-radius:0 0 50px 50px;
			padding:20px;
		}
		.product:hover{
			box-shadow:0 0 10px 3px #184d47;
		}
		
		
		
    </style>
</head>
<body>
<div class="parallax">
<div class="page-title">Grocery Cart</div>
</div>
<div class="menu" id="sticky">
<ul class="menu-ul">
     <a href="/PHPPROJECT1/cart.php" class="a-menu"><li>Product</li></a>
	 <a href="#" class="a-menu"><li>Sign up</li></a>
	 <a href="/PHPPROJECT1/userlogin.php" class="a-menu"><li>Login</li></a>
	 <a href="/PHPPROJECT1/userlogin.php" class="a-menu"><li>Logout</li></a>
	 </ul>
	 </div>

    <div class="container">
		<h2><b>Product</b></h2>

        <?php
            $query = "SELECT * FROM available_quantity ORDER BY item_no";
            $result = mysqli_query($con,$query);
            if(mysqli_num_rows($result) > 0) {

                while ($row = mysqli_fetch_array($result)) {

                    ?>
                    <div class="col-md-4">

                        <form method="post" action="cart.php?action=add&id=<?php echo $row["item_no"]; ?>">

                            <div class="product">
                                <img src="<?php echo $row["image"]; ?>" class="item-image">
                                <h5 class="text-info"><?php echo $row["item"]; ?></h5>
                                <h5 class="text-danger">$<?php echo $row["price"]; ?></h5>
                                <input type="number" name="quantity" class="form-control" value="1">
                                <input type="hidden" name="hidden_name" value="<?php echo $row["item"]; ?>">
                                <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
                                <input type="submit" name="add" style="margin-top: 5px;" class="btn btn-success"
                                       value="Add to Cart">
                            </div>
                        </form>
                    </div>
                    <?php
                }
            }
        ?>

        <div style="clear: both"></div>
        <h3 class="title2">Shopping Cart Details</h3>
        <div class="table-responsive">
            <table class="table table-bordered">
            <tr>
                <th width="30%">Product Name</th>
                <th width="10%">Quantity</th>
                <th width="13%">Price Details</th>
                <th width="10%">Total Price</th>
                <th width="17%">Remove Item</th>
            </tr>

            <?php
                if(!empty($_SESSION["cart"])){
                    $total = 0;
                    foreach ($_SESSION["cart"] as $key => $value) {
                        ?>
                        <tr>
                            <td><?php echo $value["item_name"]; ?></td>
                            <td><?php echo $value["item_quantity"]; ?></td>
                            <td>$ <?php echo $value["product_price"]; ?></td>
                            <td>
                                $ <?php echo number_format($value["item_quantity"] * $value["product_price"], 2); ?></td>
                            <td><a href="cart.php?action=delete&id=<?php echo $value["product_id"]; ?>"><span
                                        class="text-danger">Remove Item</span></a></td>

                        </tr>
                        <?php
                        $total = $total + ($value["item_quantity"] * $value["product_price"]);
                    }
                        ?>
                        <tr>
                            <td colspan="3" align="right">Total</td>
                            <th align="right">$ <?php echo number_format($total, 2); ?></th>
                            <td></td>
                        </tr>
                        <?php
                    }
                ?>
            </table><br>
        </div>

    </div>
    <form action="/PHPPROJECT1/order.php"  method="post">
      <center>  <input type="submit" name="confirm" value="confirm"></center>
    </form>
}
</body>
</html>