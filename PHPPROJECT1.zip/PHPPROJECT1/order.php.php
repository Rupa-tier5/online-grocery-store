<?php
include "connection.php";
error_reporting(0);
$ids=$_GET['id'];
if(isset($_REQUEST['Confirm']))
{
	$item=$_REQUEST['hidden_name'];
	$quantity=$_REQUEST['quantity'];
	$query="update available_quantity set order_quantity=0 where item_no=$ids";
	$res=mysqli_query($con,$query);
	if($res){
		echo "<script>alert('Thank You for shopping with us')</script>";
		echo '<script>window.location="userlogin.php"</script>';
	}
	else{
		echo "<script>aler('Confirm Your Order')</script>";
		echo '<script>window.location="cart.php"</script>';
	}
}
		