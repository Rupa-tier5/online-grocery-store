<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>adminaction</title>
</head>
<body>
</body>
</html>
<?php
  include "connection.php";
  error_reporting(0);
   $user=$_REQUEST['user'];
   $pass=$_REQUEST['pass'];
   if(isset($_REQUEST['login']))
   {
   	$sql="select * from admin where admin_id='$user'and admin_password='$pass'";
   	$result=mysqli_query($con,$sql);
   	if($result)
   	{
   		echo'<script>alert("log in sucessfull")</script>';
      echo "<script>window.location.href='/PHPPROJECT1/additem.php'</script>";
   		
   	}
   	else
   	{
   		echo'<script>alert("there is some problem")</script>';
      echo "<script>window.location.href='/PHPPROJECT1/admin.php'</script>";
   		
     }
   }
?> 