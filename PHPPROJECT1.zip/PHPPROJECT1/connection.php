<?php
$con=mysqli_connect("localhost","root","","grocery")or mysqli_connect_error();
?>